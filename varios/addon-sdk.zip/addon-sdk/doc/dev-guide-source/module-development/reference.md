# Internals > Reference #

### [api-utils](packages/api-utils/api-utils.html) ##

Documentation for the modules provided by the `api-utils` package.

### [Globals](dev-guide/module-development/globals.html) ##

Global objects available to low-level modules.