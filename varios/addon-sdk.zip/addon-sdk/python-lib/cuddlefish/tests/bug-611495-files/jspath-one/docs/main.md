minimal docs
