exports.minimalTest = function(test) {
  test.assert(true);
};
