The `plain-text-console` module provides a minimalist implementation
of the [console](dev-guide/addon-development/console.html) global,
which simply logs all messages to standard output.
