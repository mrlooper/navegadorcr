define(function () {
  return function () {
    return 'cheetah';
  };
});
