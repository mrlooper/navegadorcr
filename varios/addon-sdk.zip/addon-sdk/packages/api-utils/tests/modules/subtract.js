define(function () {
    return function (a, b) {
        return a - b;
    }
});
