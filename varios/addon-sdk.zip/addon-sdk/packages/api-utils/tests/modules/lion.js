define(function(require) {
  return 'lion';
});
