define(function (require, exports) {
  exports.name = 'tiger';
  exports.type = require('modules/types/cat').type;
});
