define(['./traditional2', 'exports'], function (traditional2, exports) {
  exports.name = 'async2';
  exports.traditional2Name = traditional2.name;
});
