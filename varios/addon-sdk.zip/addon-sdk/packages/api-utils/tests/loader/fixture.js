exports.foo = foo;
console.log('testing', 1, [2, 3, 4]);
