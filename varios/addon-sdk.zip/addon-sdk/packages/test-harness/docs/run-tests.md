<span class="aside">
For more information on testing in the Add-on SDK, see the
[Reusable Modules](dev-guide/addon-development/implementing-reusable-module.html)
tutorial.
</span>

This module contains the package's main program, which does a
bit of high-level setup and then delegates test finding and running to
the `harness` module.
